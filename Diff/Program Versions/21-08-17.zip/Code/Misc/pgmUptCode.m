function pgmUptCode

% update and remove the old ProgramVersion folder
movefile('C:\Users\uqahine4\Documents\MATLAB\Kunle\Code\ProgramVersion\Code\ProgramVersion',...
    'C:\Users\uqahine4\Documents\MATLAB\Kunle\Code\Misc');
rmdir('C:\Users\uqahine4\Documents\MATLAB\Kunle\Code\ProgramVersion\Code\');
movefile('C:\Users\uqahine4\Documents\MATLAB\Kunle\Code\Misc\ProgramVersion',...
    'C:\Users\uqahine4\Documents\MATLAB\Kunle\Code');

end